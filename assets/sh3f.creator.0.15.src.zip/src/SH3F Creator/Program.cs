﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Globalization;
using System.Resources;

namespace SH3F_Creator
{
    static class Program
    {
        /// <summary>
        /// Главная точка входа для приложения.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            // позволяем вручную выбирать язык
            //если сохранённые настройки языка отсутствуют, используем системные параметры
            if (Properties.Settings.Default.lang == null)
            {
                Properties.Settings.Default.lang = Convert.ToString(CultureInfo.CurrentCulture);
            }
            Application.Run(new Form1(Properties.Settings.Default.lang));
        }
    }
}
