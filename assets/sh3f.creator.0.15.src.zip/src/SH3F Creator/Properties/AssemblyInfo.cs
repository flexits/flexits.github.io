﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Resources;

// Управление общими сведениями о сборке осуществляется с помощью 
// набора атрибутов. Измените значения этих атрибутов, чтобы изменить сведения,
// связанные со сборкой.
[assembly: AssemblyTitle("SH3F Creator")]
[assembly: AssemblyDescription("Позволяет создавать библиотеки объектов интерьера для программы Sweet Home 3D из моделей 3DS, OBJ и LWS. Автоматически сортирует модели, создает служебный файл с описанием и сжимает все это в файл SH3F.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("4d.41.49.4c@gmail.com       Коростелин А.В.")]
[assembly: AssemblyProduct("SH3F Creator")]
[assembly: AssemblyCopyright("Лицензия GNU GPL")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Параметр ComVisible со значением FALSE делает типы в сборке невидимыми 
// для COM-компонентов.  Если требуется обратиться к типу в этой сборке через 
// COM, задайте атрибуту ComVisible значение TRUE для этого типа.
[assembly: ComVisible(false)]

// Следующий GUID служит для идентификации библиотеки типов, если этот проект будет видимым для COM
[assembly: Guid("9d93ee29-e9e0-4076-924a-6d56d7f317cc")]

// Сведения о версии сборки состоят из следующих четырех значений:
//
//      Основной номер версии
//      Дополнительный номер версии 
//      Номер построения
//      Редакция
//
// Можно задать все значения или принять номер построения и номер редакции по умолчанию, 
// используя "*", как показано ниже:
// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("0.1.0.0")]
[assembly: AssemblyFileVersion("0.1.0.0")]
[assembly: NeutralResourcesLanguageAttribute("ru-RU")]
