﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Resources;
using System.Globalization;
using System.Reflection;
using System.Threading;
using ICSharpCode.SharpZipLib.Zip;
using ICSharpCode.SharpZipLib.Checksums;

namespace SH3F_Creator
{
    public partial class Form1 : Form
    {
        public Form1(string culture)
        {
            //используем в форме заданный язык и региональные параметры
            CultureInfo cltr = new CultureInfo(culture);
            Thread.CurrentThread.CurrentCulture = cltr;
            Thread.CurrentThread.CurrentUICulture = cltr;
            InitializeComponent();
            // вспоминаем последние параметры
            textBoxInput.Text = Properties.Settings.Default.mod_path;
            textBoxPreview.Text = Properties.Settings.Default.prw_path;
            textBoxResult.Text = Properties.Settings.Default.lib_path;
            Scale_selector.Checked = Properties.Settings.Default.Scale_mode;
            maskedTextBox1.Text = Properties.Settings.Default.Scale_size;
        }
        //создаём экземпляр класса управления ресурсами
        public static ResourceManager rm = new ResourceManager("SH3F_Creator.Dialog", Assembly.GetExecutingAssembly());
        //задаём режим сортировки превью
        //если false - разрешены модели без превью, если true (по умолчанию) - то нет
        public static bool prw_mode = true;
        //подготовка содержимого библиотеки в отдельной папке
        public class PARSER
        {
            public double[] OBJ_Dimensions(string name)
            {
                double[] dimensions = new double[3]; // массив, хранящий размеры модели x, y, z
                string vertex_line; // строка с координатами вершины
                string x_line;      // строка с координатой вершины по оси x
                string y_line;      // строка с координатой вершины по оси y
                string z_line;      // строка с координатой вершины по оси z
                double min_z = 0;   // наименьшая координата вершины по оси z
                double max_z = 0;   // наибольшая координата вершины по оси z
                double z;
                double min_y = 0;
                double max_y = 0;
                double y;
                double min_x = 0;
                double max_x = 0;
                double x;
                // считываем строки из файла .OBJ в массив
                string[] lines = File.ReadAllLines(name);
                //обрабатываем каждую строку
                foreach (string line in lines)
                {
                    // убираем лишние пробелы
                    line.Trim();
                    // если строка начинается идентификатором "v ", то она содержит координаты вершин
                    // остальные строки нас не интересуют
                    if (line.StartsWith("v ", true, null))
                    {
                        //строка имеет вид "v 0.123 0.234 0.345"
                        //убираем идентификатор в начале
                        vertex_line = line.Substring(2);
                        //обрезаем всё, кроме первой группы цифр - это x координата
                        x_line = vertex_line.Remove(vertex_line.IndexOf(" ")).Trim();
                        //обрезаем первую и третью группы цифр - это y
                        y_line = vertex_line.Remove(vertex_line.LastIndexOf(" ")).Trim();
                        y_line = y_line.Substring(y_line.LastIndexOf(" ")).Trim();
                        //обрезаем всё, кроме последней группы цифр - это z
                        z_line = vertex_line.Substring(vertex_line.LastIndexOf(" ")).Trim();
                        //преобразовываем координаты из текста в числа
                        x = double.Parse(x_line, CultureInfo.InvariantCulture.NumberFormat);
                        y = double.Parse(y_line, CultureInfo.InvariantCulture.NumberFormat);
                        z = double.Parse(z_line, CultureInfo.InvariantCulture.NumberFormat);
                        // если указанная в этой строке x координата меньше минимальной,
                        // заменяем её значением значение минимальной
                        if (x < min_x)
                        {
                            min_x = x;
                        }
                        else
                            // если указанная в этой строке x координата больше максимальной,
                            // заменяем её значением значение максимальной
                            if (x > max_x)
                            {
                                max_x = x;
                            }
                        // после проверки всех строк получим наименьшую и наибольшую x координаты
                        // аналогично для осей y и z
                        if (y < min_y)
                        {
                            min_y = y;
                        }
                        else
                            if (y > max_y)
                            {
                                max_y = y;
                            }
                        if (z < min_z)
                        {
                            min_z = z;
                        }
                        else
                            if (z > max_z)
                            {
                                max_z = z;
                            }
                    }
                }
                // вычисляем длину отрезка проекции модели на каждую координатную ось
                // как разность максимального и минимального значения координат
                x = max_x - min_x;
                y = max_y - min_y;
                z = max_z - min_z;
                // округляем длину отрезка до целого
                dimensions[0] = Math.Round(x, 0);
                dimensions[1] = Math.Round(y, 0);
                dimensions[2] = Math.Round(z, 0);
                return dimensions;
            }
            // получаем размеры проекции модели
            public double[] scaler(double[] dimensions, double min)
            {
                double dimensions_min = dimensions[0];
                //размер минимальной проекции заданной модели
                foreach (double D in dimensions)
                {
                    if (dimensions_min > D)
                    {
                        dimensions_min = D;
                    }
                }
                //ищем минимальную проекцию
                if (dimensions_min < min)
                {
                    double multiplier = min / dimensions_min;
                    for (int i = 0; i < dimensions.Length; ++i )
                    {
                        dimensions[i] = dimensions[i] * multiplier;
                        dimensions[i] = Math.Round(dimensions[i], 0);
                    }
                }
                //если она меньше заданного минимума, растягиваем модель
                return dimensions;
            }
            // проекции некоторых моделей могут быть очень маленькими, например 2*3*11
            // в таком случае их нужно увеличить, сохраняя пропорции
        }
        // парсер моделей
        public class model_process
        {
            public int MODEL_COUNTER; // номер модели в массиве имен, он же счетчик моделей
            public string MODEL; // имя модели, соответствующее номеру
            public string MODELNAME; // имя модели без расширения
            public string OUTPUT; //папка, в которую копировать модели
            public string MSOURCE; //откуда копировать модели
            public string PREVIEW; //имя файла превьюшки
            public string PSOURCE; //откуда копировать превьюшки
            public string CATEGORY; //название категории модели
            public string CAT; //имя файла каталога
            public bool Scale_mode; //включить или выключить масштабирование моделей
            public double Scale_size; //размер, до которого будем растягивать модель
            public string uconvert(string INPUT)
            {
                string u_str = null;
                int count = 0;
                foreach (char symbol in INPUT)
                {
                    u_str = u_str + '\\' + "u" + Char.ConvertToUtf32(INPUT, count).ToString("X").PadLeft(4,'\u0030') ;
                    ++count;
                }
                return u_str;
            }
            // конвертация символов в их HEX коды по таблице Unicode
            // для обеспечения поддержки русского и других языков
            public void PROCESS()
            {
                PARSER parse = new PARSER();
                double[] dimensions = new double[]{50,50,50};
                // массив для хранения размеров моделей
                Directory.CreateDirectory(OUTPUT + '\\' + MODELNAME);
                //создаем папку для моделей и копируем туда модель
                File.Copy(MSOURCE + '\\' + MODEL, OUTPUT + '\\' + MODELNAME + '\\' + MODEL, true);
                bool prw_found = true;
                //индикатор ниличия превью для обрабатываемой модели
                try
                {
                    File.Copy(PSOURCE + '\\' + PREVIEW, OUTPUT + '\\' + PREVIEW, true);
                    //пытаемся скопировать файл превью
                }
                catch (FileNotFoundException)
                {
                    prw_found = false;
                    //если превью отсутствует, изменяем индикатор
                };
                ++MODEL_COUNTER; //увеличиваем счётчик скопированных моделей
                FileInfo fi = new FileInfo(CAT);
                using (StreamWriter sw = fi.AppendText())
                {
                    //пишем информацию в файл описания библиотеки "PluginFurnitureCatalog.properties"
                    sw.WriteLine("name#" + MODEL_COUNTER + "=" + uconvert(MODELNAME));
                    sw.WriteLine("category#" + MODEL_COUNTER + "=" + uconvert(CATEGORY));
                    if (prw_found)
                    {
                        sw.WriteLine("icon#" + MODEL_COUNTER + "=/" + PREVIEW);
                        //если для модели существует превью, вносим информацию о нём
                    }
                    sw.WriteLine("model#" + MODEL_COUNTER + "=/" + MODELNAME + "/" + MODEL);
                    sw.WriteLine("multiPartModel#" + MODEL_COUNTER + "=true");
                    if (MODEL.EndsWith(".obj", true, null))
                    {
                        try
                        {
                            File.Copy(MSOURCE + '\\' + MODELNAME + ".mtl", OUTPUT + '\\' + MODELNAME + '\\' + MODELNAME + ".mtl", true);
                            //копируем файл .mtl для моделей Wavefront OBJ
                        }
                        catch (FileNotFoundException) { };
                        //а вообще-то его может и не быть
                        //парсинг .OBJ файла для определения размеров модели
                        dimensions = parse.OBJ_Dimensions(MSOURCE + '\\' + MODEL);
                        if (Scale_mode)
                        {
                            //масштабирование модели
                            dimensions = parse.scaler(dimensions, Scale_size);
                        }
                        //записываем в файл описания полученные значения
                        sw.WriteLine("width#" + MODEL_COUNTER + "=" + System.Convert.ToString(dimensions[0]));
                        sw.WriteLine("depth#" + MODEL_COUNTER + "=" + System.Convert.ToString(dimensions[1]));
                        sw.WriteLine("height#" + MODEL_COUNTER + "=" + System.Convert.ToString(dimensions[2]));
                    }
                    else
                    {
                        // остальные типы моделей запихиваем в квадратный ящик постоянного размера
                        sw.WriteLine("width#" + MODEL_COUNTER + "=50");
                        sw.WriteLine("depth#" + MODEL_COUNTER + "=50");
                        sw.WriteLine("height#" + MODEL_COUNTER + "=50");
                    }
                    sw.WriteLine("movable#" + MODEL_COUNTER + "=true");
                    sw.WriteLine("doorOrWindow#" + MODEL_COUNTER + "=false");
                    sw.WriteLine();
                }
            }
            // копирование файлов и создание описания (PluginFurnitureCatalog.properties)
        }
        //сортировка моделей и проверка папок
        public class sorter
        {
            //отбор и сортировка моделей
            public string[] inp_sort (string INPUT)
            {
                DirectoryInfo inp_dir = new DirectoryInfo(INPUT);
                FileInfo[] inp_names = inp_dir.GetFiles(); // имена файлов в исходном каталоге
                string[] m_names = new string[inp_names.Length]; //массив для имен моделей
                int m_count = 0; //кол-во моделей
                foreach (FileInfo file in inp_names)
                {
                    string fname = System.Convert.ToString(file);
                    if (fname.EndsWith(".3ds", true, null) || fname.EndsWith(".obj", true, null) || fname.EndsWith(".lws", true, null))
                    {
                        m_names[m_count] = fname;
                        ++m_count;
                    }
                }//отбираем файлы с нужными расширениями, копируем имена в массив и считаем их
                string[] names = new string[m_count];
                Array.Copy(m_names, names, m_count);
                //для имен моделей создаем массив правильной длины и копируем их в него
                return names; //возвращаем этот массив
            }
            //отбор и сортировка превью
            public string[] prw_sort(string PINPUT, int P)
            {
                //получаем имена файлов превью
                DirectoryInfo prw_dir = new DirectoryInfo(PINPUT);
                FileInfo[] fprw_names = prw_dir.GetFiles("*.png");
                //задаём массив для хранения имён файлов превью
                string[] prw_names = new string[P];
                //и заполняем его
                for (int k = 0; k != P; ++k)
                {
                    prw_names[k] = System.Convert.ToString(fprw_names[k]);
                }
                return prw_names;
            }
            //проверка названия категории
            //оно не должно быть пустым и состоять из пробелов
            public bool cat_check(string CATEGORY)
            {
                bool check=(CATEGORY.Length==0);
                if (check)
                {
                    MessageBox.Show(rm.GetString("no_cat", CultureInfo.CurrentCulture), "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    check = false;
                }
                else
                {
                    CATEGORY.Trim();
                    if (CATEGORY.Length == 0)
                    {
                        MessageBox.Show(rm.GetString("no_cat", CultureInfo.CurrentCulture), "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        check = true;
                    }
                }
                return check;
            }
            //проверка папки с моделями
            //она должна существовать и содержать хотя бы одну поддерживаемую модель
            public bool inp_check(string INPUT)
            {
                bool check = Directory.Exists(INPUT);
                int m_count = 0;
                if (check)
                {
                    string[] files = Directory.GetFiles(INPUT);
                    foreach (string file in files)
                    {
                        if (file.EndsWith(".3ds", true, null) || file.EndsWith(".obj", true, null) || file.EndsWith(".lws", true, null))
                        {
                            ++m_count;
                        }
                    }
                    if (m_count == 0)
                    {
                        check = false;
                        MessageBox.Show(rm.GetString("models_unsupp", CultureInfo.CurrentCulture), "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }

                }
                else
                {
                    MessageBox.Show(rm.GetString("models_not_exist", CultureInfo.CurrentCulture), "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    check = false;
                }
                return check;
            }
            //проверка папки для библиотеки
            //она должна существовать и быть доступной для записи
            public bool out_check(string OUTPUT)
            {
                bool check = false;
                if (Directory.Exists(OUTPUT))
                {
                    try
                    {
                        Directory.CreateDirectory(OUTPUT + '\\' + "test");
                        Directory.Delete(OUTPUT + '\\' + "test", true);
                        check = true;
                    }
                    catch
                    {
                        MessageBox.Show(rm.GetString("out_check_rw", CultureInfo.CurrentCulture), "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        check = false;
                    }
                }
                else
                {
                    try
                    {
                        Directory.CreateDirectory(OUTPUT);
                        Directory.Delete(OUTPUT, true);
                        check = true;
                    }
                    catch
                    {
                        //MessageBox.Show("Невозможно создать папку по заданному пути." + '\n' + "Выберите другую.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        MessageBox.Show(rm.GetString("out_check_rr", CultureInfo.CurrentCulture), "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        check = false;
                    }
                }
                return check;
            }
            //проверка папки с превьюшками. она должна существовать и содержать картинки .PNG
            //если запрещен режим создания библиотеки моделей без превью
            //в папке должно быть не меньше картинок, чем моделей
            public bool prw_check(string PINPUT, int m_count)
            {
                bool check = Directory.Exists(PINPUT);
                if (!check)
                {
                    MessageBox.Show(rm.GetString("prw_not_exist", CultureInfo.CurrentCulture), "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return check;
                }
                else
                {
                    check = true;
                }
                
                if (prw_mode && (Directory.GetFiles(PINPUT, "*.png").Length == 0))
                {
                    MessageBox.Show(rm.GetString("prw_empty", CultureInfo.CurrentCulture), "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    check = false;
                }
                else
                {
                    if (prw_mode && (Directory.GetFiles(PINPUT, "*.png").Length < m_count))
                    {
                        MessageBox.Show(rm.GetString("prw_small", CultureInfo.CurrentCulture), "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        check = false;
                    }
                    else
                    {
                        check = true;
                    }
                }
                return check;
            }
        }
        //этот класс создает саму библиотеку - zip архив с моделями
        public class zip_create
        {
            public void shf3(string name, string inp_dir)
            {
                name = inp_dir.Remove(inp_dir.LastIndexOf('\\')) + '\\' + name + ".sh3f";
                //добавляем путь и расширение
                //путь - каталог, в котором лежит папка с содержимым архива
                FastZip fZip = new FastZip();
                fZip.CreateZip(name, inp_dir, true, "");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            sorter chks = new sorter();
            toolStripStatusLabel1.Text = rm.GetString("cat_check", CultureInfo.CurrentCulture);
            if (!(chks.cat_check(CatName.Text))) goto Cancel;
            toolStripStatusLabel1.Text = rm.GetString("inp_check", CultureInfo.CurrentCulture);
            if (!(chks.inp_check(textBoxInput.Text))) goto Cancel;
            toolStripStatusLabel1.Text = rm.GetString("out_check", CultureInfo.CurrentCulture);
            if (!(chks.out_check(textBoxResult.Text))) goto Cancel;
            toolStripStatusLabel1.Text = rm.GetString("inp_sort", CultureInfo.CurrentCulture);
            string[] names = chks.inp_sort(textBoxInput.Text);
            //получаем массив с именами моделей
            int m_count = names.Length;
            //количество моделей
            toolStripStatusLabel1.Text = rm.GetString("prw_check", CultureInfo.CurrentCulture);
            if (!(chks.prw_check(textBoxPreview.Text, m_count))) goto Cancel;
            //проверяем доступность нужного количества моделей
            textBoxResult.Text = textBoxResult.Text + '\\' + LibraryName.Text;
            textBoxInput.ReadOnly = true;
            textBoxPreview.ReadOnly = true;
            LibraryName.ReadOnly = true;
            CatName.ReadOnly = true;
            button1.Enabled = false;
            button2.Enabled = button3.Enabled = button4.Enabled = false;
            Scale_selector.Enabled = false;
            //делаем текст в полях ввода недоступным для изменения
            Directory.CreateDirectory(textBoxResult.Text);
            //creating output directory with the specified name
            using (StreamWriter sw = File.CreateText(textBoxResult.Text + '\\' + "PluginFurnitureCatalog.properties")) { };
            //создаем файл с описанием библиотеки моделей
            model_process mp = new model_process();
            mp.MODEL_COUNTER = 0;
            //создаем класс обработки моделей и инициализируем счетчик
            mp.MSOURCE = textBoxInput.Text;
            //задаем исходный каталог
            mp.PSOURCE = textBoxPreview.Text;
            //задаем каталог с превьюшками
            mp.CAT = (textBoxResult.Text + '\\' + "PluginFurnitureCatalog.properties");
            //задаем имя файла каталога
            mp.CATEGORY = CatName.Text;
            //задаем название категории моделей
            mp.OUTPUT = textBoxResult.Text;
            //задаем каталог, куда скопировать модель
            mp.Scale_mode = Scale_selector.Checked;
            mp.Scale_size = System.Convert.ToDouble(maskedTextBox1.Text);
            //управление масштабированием
                for (int i = 0; i != m_count; ++i)
                {
                    mp.MODEL = names[mp.MODEL_COUNTER];
                    //считываем имя файла модели, соответствующего положению счетчика
                    mp.MODELNAME = mp.MODEL.Remove(mp.MODEL.LastIndexOf("."));
                    //задаем имя модели без расширения
                    if (prw_mode)
                    {
                        mp.PREVIEW = chks.prw_sort(textBoxPreview.Text, m_count)[mp.MODEL_COUNTER];
                        //если запрещено добавление моделей без превью,
                        //проверяем и сортируем картинки
                    }
                    else
                    {
                        mp.PREVIEW = mp.MODELNAME + ".png";
                        //если разрешено добавление моделей без превью,
                        //имена файлов превью должны соответствовать именам файлов моделей
                    }
                    mp.PROCESS();
                    progressBar1.Value = mp.MODEL_COUNTER * 100 / m_count;
                    //запускаем обработку, затем увеличиваем значение прогресс - бара
                }
                toolStripStatusLabel1.Text = rm.GetString("processed", CultureInfo.CurrentCulture) + mp.MODEL_COUNTER + rm.GetString("models", CultureInfo.CurrentCulture);
            zip_create library = new zip_create();
            library.shf3(LibraryName.Text, textBoxResult.Text);
            toolStripStatusLabel1.Text = rm.GetString("library", CultureInfo.CurrentCulture) + LibraryName.Text + rm.GetString("created", CultureInfo.CurrentCulture);
            Directory.Delete(textBoxResult.Text, true);
       Cancel:
            textBoxInput.ReadOnly = false;
            textBoxPreview.ReadOnly = false;
            LibraryName.ReadOnly = false;
            CatName.ReadOnly = false;
            button1.Enabled = true;
            button2.Enabled = button3.Enabled = button4.Enabled = true;
            Scale_selector.Enabled = true;
            //исходное состояние элементов формы;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            folderBrowserDialog1.SelectedPath = textBoxInput.Text;
            folderBrowserDialog1.ShowDialog();
            textBoxInput.Text = folderBrowserDialog1.SelectedPath;
            progressBar1.Value = 0;
            //задаем место для библиотеки
            textBoxResult.Text = textBoxInput.Text;
            //задаём место для превью
            textBoxPreview.Text = textBoxInput.Text;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            folderBrowserDialog2.SelectedPath = textBoxPreview.Text;
            folderBrowserDialog2.ShowDialog();
            textBoxPreview.Text = folderBrowserDialog2.SelectedPath;
            progressBar1.Value = 0;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            folderBrowserDialog3.SelectedPath = textBoxResult.Text;
            folderBrowserDialog3.ShowDialog();
            textBoxResult.Text = folderBrowserDialog3.SelectedPath;
        }

        private void моделиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            folderBrowserDialog1.ShowDialog();
            textBoxInput.Text = folderBrowserDialog1.SelectedPath;
            progressBar1.Value = 0;
            //задаем место для библиотеки
            textBoxResult.Text = textBoxInput.Text;
            //задаём место для превью
            textBoxPreview.Text = textBoxInput.Text;
        }

        private void превьюToolStripMenuItem_Click(object sender, EventArgs e)
        {
            folderBrowserDialog2.ShowDialog();
            textBoxPreview.Text = folderBrowserDialog2.SelectedPath;
        }

        private void библиотекаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            folderBrowserDialog3.ShowDialog();
            textBoxResult.Text = folderBrowserDialog3.SelectedPath;
        }

        private void englishToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Properties.Settings.Default.lang = "en-US";
            //меняем язык, перезапускаем программу
            Application.Restart();
        }

        private void русскийToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Properties.Settings.Default.lang = "ru-RU";
            //меняем язык, перезапускаем программу
            Application.Restart();
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            //при закрытии формы сохраняем параметры и выходим из программы
            Properties.Settings.Default.mod_path = textBoxInput.Text;
            Properties.Settings.Default.prw_path = textBoxPreview.Text;
            Properties.Settings.Default.lib_path = textBoxResult.Text;
            Properties.Settings.Default.Scale_mode = Scale_selector.Checked;
            Properties.Settings.Default.Scale_size = maskedTextBox1.Text;
            Properties.Settings.Default.Save();
            Application.Exit();
        }

        //переключатель режима использования превью
        //разрешение/запрет добавления моделей без превью
        private void prw_sort_MenuItem_Click(object sender, EventArgs e)
        {
            if (prw_mode)
            {
                prw_sort_MenuItem.Text = rm.GetString("sort_name", CultureInfo.CurrentCulture);
                prw_mode = false;
            }
            else
            {
                prw_sort_MenuItem.Text = rm.GetString("sort_num", CultureInfo.CurrentCulture);
                prw_mode = true;
            }
        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Properties.Settings.Default.mod_path = textBoxInput.Text;
            Properties.Settings.Default.prw_path = textBoxPreview.Text;
            Properties.Settings.Default.lib_path = textBoxResult.Text;
            Properties.Settings.Default.Scale_mode = Scale_selector.Checked;
            Properties.Settings.Default.Scale_size = maskedTextBox1.Text;
            Properties.Settings.Default.Save();
            Application.Exit();
        }

        private void оПрограммеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AboutBox1 aboutbox1 = new AboutBox1();
            aboutbox1.Show();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
